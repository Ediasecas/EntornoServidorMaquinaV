package com.tuempresa.bibliodaw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliodawApplicationTests {

	@Test
	void contextLoads() {
	}

}
