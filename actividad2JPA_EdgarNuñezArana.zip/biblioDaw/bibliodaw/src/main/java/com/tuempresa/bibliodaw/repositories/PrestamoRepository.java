package com.tuempresa.bibliodaw.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import com.tuempresa.bibliodaw.entities.Prestamo;
public interface PrestamoRepository extends
JpaRepository<Prestamo, Integer> {
}
