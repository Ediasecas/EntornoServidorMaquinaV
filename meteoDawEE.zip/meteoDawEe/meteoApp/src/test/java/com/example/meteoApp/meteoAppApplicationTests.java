package com.example.meteoApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class meteoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
