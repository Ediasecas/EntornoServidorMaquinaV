package com.almacenlibros.service;

import com.almacenlibros.model.Libro;
import com.almacenlibros.repository.LibroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LibroService {

    @Autowired
    private LibroRepository libroRepository;

    public List<Libro> obtenerTodosLosLibros() {
        return libroRepository.findAll();
    }

    public Optional<Libro> obtenerLibroPorId(Long id) {
        return libroRepository.findById(id);
    }

    public Libro alquilarLibro(Long id) {
        Libro libro = libroRepository.findById(id).orElseThrow(() -> new RuntimeException("Libro no encontrado"));
        libro.setAlquilado(true);
        return libroRepository.save(libro);
    }

    public Libro agregarLibro(Libro libro) {
        return libroRepository.save(libro);
    }
}
