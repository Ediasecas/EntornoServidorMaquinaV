package com.almacenlibros.controller;

import com.almacenlibros.model.Libro;
import com.almacenlibros.service.LibroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/libros")
public class LibroController {

    @Autowired
    private LibroService libroService;

    // Método para obtener todos los libros
    @GetMapping
    public List<Libro> obtenerTodosLosLibros() {
        return libroService.obtenerTodosLosLibros();
    }

    // Método para obtener un libro por ID
    @GetMapping("/{id}")
    public Optional<Libro> obtenerLibroPorId(@PathVariable Long id) {
        return libroService.obtenerLibroPorId(id);
    }

    // Método para alquilar un libro por ID
    @PutMapping("/alquilar/{id}")
    public Libro alquilarLibro(@PathVariable Long id) {
        return libroService.alquilarLibro(id);
    }

    // Método POST para agregar un libro
    @PostMapping
    public Libro agregarLibro(@RequestBody Libro libro) {
        return libroService.agregarLibro(libro);
    }
}
